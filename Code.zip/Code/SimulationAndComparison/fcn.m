
function y=fcn(t)
    q=5;   
    y=zeros(q,1);

    y(1)=1;
    y(2)=sqrt(2)*sin(t);   
    y(3)=sqrt(2)*cos(t);
    y(4)=sqrt(2)*sin(2*t);   
    y(5)=sqrt(2)*cos(2*t);  
end
