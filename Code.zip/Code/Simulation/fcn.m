



function y=fcn(t)
    q=5;    
    y=zeros(q,1);


    y(1)=1;
    y(2)=sqrt(2)*sin(4*t);   
    y(3)=sqrt(2)*cos(4*t);
    y(4)=sqrt(2)*sin(8*t);  
    y(5)=sqrt(2)*cos(8*t);   
end
